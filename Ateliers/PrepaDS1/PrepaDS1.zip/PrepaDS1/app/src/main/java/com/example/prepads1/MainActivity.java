package com.example.prepads1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText tailleInput;
    private RadioGroup genreRadioGroup;
    private Button calculerButton;
    private Button effacerButton;
    private TextView resultatText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tailleInput = findViewById(R.id.nbr1);
        genreRadioGroup = findViewById(R.id.gender);
        calculerButton = findViewById(R.id.compute);
        effacerButton = findViewById(R.id.cancel);
        resultatText = findViewById(R.id.result);

        calculerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculerPoidsIdeal();
            }
        });

        effacerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                effacerInput();
            }
        });
    }

    private void calculerPoidsIdeal() {
        int taille = Integer.parseInt(tailleInput.getText().toString());
        int poidsIdeal;

        int selectedGenreId = genreRadioGroup.getCheckedRadioButtonId();
        RadioButton genreRadioButton = findViewById(selectedGenreId);
        String genre = genreRadioButton.getText().toString();

        if (genre.equals("Male")) {
            poidsIdeal = taille - 100 - ((taille - 150) / 4);
        } else {
            poidsIdeal = taille - 100 - ((taille - 150) / 25);
        }

        resultatText.setText("            " + poidsIdeal);
    }

    private void effacerInput() {
        tailleInput.setText("");
    }
}
